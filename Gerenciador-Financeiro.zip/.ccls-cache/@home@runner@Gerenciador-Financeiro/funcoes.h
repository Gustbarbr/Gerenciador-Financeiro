#include <stdio.h>

int receitas();

int gastos();

int Meses();

int mes();

int investimento();

int gerenciador();